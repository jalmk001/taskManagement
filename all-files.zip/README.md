Task Management Application


Login Details
Email:- jalva@admin.com
Password:- 12345678

npm install (For laravel auth)
composer update
npm run dev (For laravel auth)
php artisan serve


Import Database File (task.sql.gz)
DB_DATABASE=Task
DB_USERNAME=root
DB_PASSWORD=root
