<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
<p><?php echo e(session()->get('message')); ?></p>
<?php endif; ?>
    <div class="nk-content ">
        <?php if($errors->any()): ?>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error-message" class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error-message" class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div id="error-message" class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php endif; ?>


        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title">
                                    Tasks</h3>
                                <div class="nk-block-des text-soft">
                                </div>
                            </div>

                            <div class="nk-block-head-content">
                                <div class="toggle-wrap nk-block-tools-toggle"><a href="#"
                                        class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="more-options"><em
                                            class="icon ni ni-more-v"></em></a>
                                    <div class="toggle-expand-content" data-content="more-options">
                                        <ul class="nk-block-tools g-3">
                                            <li class="nk-block-tools-opt"><button
                                                    class="btn btn-primary d-none d-md-inline-flex" data-toggle="modal"
                                                    data-target="#create"><em class="icon ni ni-plus"></em><span>Add
                                                        Task</span></button>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nk-block">
                        <div class="nk-tb-list is-separate mb-3">
                            <div class="nk-tb-item nk-tb-head">
                                <div class="nk-tb-col tb-col-mb text-center"><span class="sub-text">Title</span></div>
                                <div class="nk-tb-col tb-col-mb text-center"><span class="sub-text">Description</span></div>
                                <div class="nk-tb-col tb-col-md text-center"><span class="sub-text">Due Date</span></div>
                                <div class="nk-tb-col tb-col-md text-center"><span class="sub-text">Action</span></div>
                            </div>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="nk-tb-item">
                                    <div class="nk-tb-col tb-col-mb text-center">
                                        <span class="tb-lead"><?php echo e($task->title); ?></span>
                                    </div>
                                    <div class="nk-tb-col tb-col-mb text-center">
                                        <span class="tb-amount"><?php echo e($task->description); ?></span>
                                    </div>
                                    <div class="nk-tb-col tb-col-md text-center">
                                        <span><?php echo e($task->getDueDateFormattedAttribute()); ?></span>
                                    </div>
                                    <div class="nk-tb-col tb-col-md text-center">
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('tasks.show', $task->id)); ?>" class="btn btn-primary"><i
                                                    class="fa fa-eye"></i></a>
                                            <button type="button" class="btn btn-secondary" data-toggle="modal"
                                                data-target="#updateTaskModal<?php echo e($task->id); ?>"><i class="fa fa-edit"></i>
                                                <button type="button" class="btn btn-danger" data-toggle="modal"
                                                    data-target="#delete-<?php echo e($task->id); ?>"><i class="fa fa-trash"></i>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <?php echo e($tasks->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('Tasks.addTask', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Tasks.updateTask', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('Tasks.deleteTask', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Master.layouts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jalva Jabin\Desktop\Laravel\taskManagement\resources\views/Tasks/tasks.blade.php ENDPATH**/ ?>