<div class="nk-sidebar nk-sidebar-fixed is-light " data-content="sidebarMenu">
    <div class="nk-sidebar-element nk-sidebar-head">
    </div>
    <div class="nk-sidebar-element">
        <div class="nk-sidebar-content">
            <div class="nk-sidebar-menu" data-simplebar>
                <ul class="nk-menu">
                    <li class="nk-menu-item"><a href="{{ route('home') }}" class="nk-menu-link"><span
                                class="nk-menu-icon"><em class="icon ni ni-dashboard"></em></span><span
                                class="nk-menu-text" style="line-height: 25px">Task Management</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
